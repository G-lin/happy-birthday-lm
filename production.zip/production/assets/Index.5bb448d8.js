import{r,o as e,c as n}from"./vendor.23132fa0.js";const o={name:"Index"};o.render=function(o,t,a,s,c,d){const f=r("router-view");return e(),n(f)};export default o;
